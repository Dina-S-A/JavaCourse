//import java.io.IOException;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;
import javafx.stage.Stage;

public class TestAssociation extends Application {
	
		//Declare association
		private Association association;
		int numberOfMembers;
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//Text Fields for main window
	   private TextField tfAssociationName = new TextField();
	   private TextField tfNumberOfMembers = new TextField();
	   private TextField tfShareAmount = new TextField();
	   private TextField tfStartMonth = new TextField();
	   private TextField tfAdminName = new TextField();
	   private TextField tfAdminId = new TextField();
	   private TextField tfAdminEmail = new TextField();
	   private TextField tfAdminPhone = new TextField();
	   //Add member window controls.
	   private TextField tfMemberName = new TextField();
	   private TextField tfMemberId = new TextField();
	   private TextField tfMemberEmail = new TextField();
	   private TextField tfMemberPhone = new TextField();
	   private Button btAddMember = new Button("Add Member");
	  // private Button btCreatePaidTable= new Button("Create Payment Table");
	   private Label lblCreatePT = new Label(" ");
	   private Label lblUpdatePT = new Label("Do you like to update payment table? ");
	   private Button btUpdatePaidTable= new Button("Yes");
	   
	   //Add member window Buttons
	   private Button btCreate = new Button("Create Association");	   
	   private Button btView = new Button("View Association Details");
	  
	   
	   //Add Payment window controls
	   private Label lblPRMember = new Label("Enter Member's Name: ");
	   private TextField tfPRMember = new TextField();
	   private Label lblUpdateMonth = new Label("Enter Month number you want to update (0 for recepient!): ");
	   private TextField tfUpdateMonth = new TextField();
	   private Label lblPaidRecieved = new Label("Member Paid/Recieved: ");
	   private TextField tfPaidRecieved = new TextField();
	   private Button btUpdatePaymentTable = new Button("Update Payment Table");
	   private Button btViewPaymentTable = new Button("View Payment Table");
	   
	   
	   
	   @Override // Override the start method in the Application class
	   public void start(Stage primaryStage) {
	     // Create UI
	     GridPane gridPane = new GridPane();
	     gridPane.setPadding(new Insets(5, 15, 5, 0));
	     gridPane.setHgap(5);
	     gridPane.setVgap(5);
	     gridPane.add(new Label(" Association Name:"), 0, 0);
	     gridPane.add(tfAssociationName, 1, 0);
	     gridPane.add(new Label("Number of Members:"), 0, 1);	     
	     gridPane.add(tfNumberOfMembers, 1, 1); 
	     gridPane.add(new Label("Share Amount:"), 0, 2);
	     gridPane.add(tfShareAmount, 1, 2);
	     gridPane.add(new Label("Start month and year ex. Sep.2021:"), 0, 3);	     
	     gridPane.add(tfStartMonth, 1, 3);      	 
	     gridPane.add(new Label("Administrator Information:"), 0, 5);
	     gridPane.add(new Label("Administrator Name:"), 0, 6);
	     gridPane.add(tfAdminName, 1, 6);
	     gridPane.add(new Label("Administrator ID number:"), 0, 7);	     
	     gridPane.add(tfAdminId, 1, 7);    
	     gridPane.add(new Label("Email:"), 0, 8);	     
	     gridPane.add(tfAdminEmail, 1, 8);      	 
	     gridPane.add(new Label("Phone Number:"), 0, 9);
	     gridPane.add(tfAdminPhone, 1, 9);
	     gridPane.add(btCreate, 1, 10); 
	  
	
	    // Set properties for UI
	     gridPane.setAlignment(Pos.CENTER);
	     tfAssociationName.setAlignment(Pos.BOTTOM_RIGHT);
	     tfNumberOfMembers.setAlignment(Pos.BOTTOM_RIGHT);	 
	     tfShareAmount.setAlignment(Pos.BOTTOM_RIGHT);	         
	     tfStartMonth.setAlignment(Pos.BOTTOM_RIGHT);	         
	     tfAdminName.setAlignment(Pos.BOTTOM_RIGHT);	         
	     tfAdminId.setAlignment(Pos.BOTTOM_RIGHT);	 
	     tfAdminEmail.setAlignment(Pos.BOTTOM_RIGHT);
	     tfAdminPhone.setAlignment(Pos.BOTTOM_RIGHT);

	    	     
	   // tfDone.setEditable(false);
	    GridPane.setHalignment(btCreate, HPos.CENTER);
 
	    // Process events
	    btCreate.setOnAction(e -> createAssociation()) ;
	   
	    
	     // Create a scene and place it in the stage
	     Scene scene = new Scene(gridPane, 400, 500);
	     primaryStage.setTitle("Association"); // Set title
	     primaryStage.setScene(scene); // Place the scene in the stage
	     primaryStage.show(); // Display the stage
	   }
	   
	   //////////////////////////////////////////////////////////////////////////////////////
	   //Create Association Object
	   public void createAssociation() {
		   try {
		  // Get information from GUI
		  String associationName = tfAssociationName.getText();
		  this.numberOfMembers =  Integer.parseInt(tfNumberOfMembers.getText());  		  
		  float shareAmount = Float.parseFloat(tfShareAmount.getText());
		  String startMonth = tfStartMonth.getText();
		  String adminName = tfAdminName.getText();
		  String adminId = tfAdminId.getText();
		  String adminEmail = tfAdminEmail.getText();
		  String adminPhone = tfAdminPhone.getText();
		  
		  //1-Create Association
		   association = new Association(associationName,numberOfMembers,shareAmount,startMonth);
		  
		  //2- Construct Administrator.
		  association.setAdmin(adminName, adminId, adminEmail, adminPhone, true);
		  
		  ////////////////////////////////////////////////////////////////////////////////
		  //3- Fill Association members ArrayList by opening new window	 
		  //Creating And Displaying Add Member Window
		    
		   
				
				
				GridPane mambersWindow = new GridPane();
				mambersWindow.setPadding(new Insets(5, 15, 5, 0));
				mambersWindow.setHgap(5);
				mambersWindow.setVgap(5);
				mambersWindow.add(new Label("Enter Members Information in the recipients order"), 0, 0);
				mambersWindow.add(new Label("Member's Name:"), 0, 1);
				mambersWindow.add(tfMemberName, 1, 1);
				mambersWindow.add(new Label("Members ID number:"), 0,2);	     
				mambersWindow.add(tfMemberId, 1, 2);    
				mambersWindow.add(new Label("Email:"), 0, 3);	     
				mambersWindow.add(tfMemberEmail, 1, 3);      	 
				mambersWindow.add(new Label("Phone Number:"), 0, 4);
				mambersWindow.add(tfMemberPhone, 1, 4);
				//Add member buttons
				mambersWindow.add(btAddMember, 0, 6);	
				//Creating payment table
				
				//mambersWindow.add(new Label("Create payment table after adding all members!!"), 0, 7);
				//mambersWindow.add(btCreatePaidTable, 0, 8);
				mambersWindow.add(lblCreatePT,0,9);
				mambersWindow.add(btView, 0,10);
				mambersWindow.add(lblUpdatePT,0,11);		
				mambersWindow.add(btUpdatePaidTable, 1,11);
				
				
				
				mambersWindow.setAlignment(Pos.CENTER);
				Scene membersScene = new Scene(mambersWindow, 500, 400);
				
				 btAddMember.setOnAction(e -> addMember());
				 //btCreatePaidTable.setOnAction(e -> CreatePaidTable());
				 btView.setOnAction(e -> viewAssociation());
				 btUpdatePaidTable.setOnAction(e -> openPaidTableWindow());

				// New window (Stage)
				Stage addingMembersWindow = new Stage();
				addingMembersWindow.setTitle("Add Members");
				addingMembersWindow.setScene(membersScene);				

				addingMembersWindow.show();
		   }catch (Exception ex) {
			  // ex.printStackTrace();
			   System.out.println ("WRONG DATA WAS ENTERED !!");
			   }		
	 }	
	
		
		/////////////////////////////////////////////////////////////////////////////////
		//Adding members to association members list
		 int counter = 0;
		  public void addMember() {
			  
			 try {
				 
				 
				 String memberName = tfMemberName.getText().trim();			
				 String memberId = tfMemberId.getText().trim();					
				 String memberEmail =tfMemberEmail.getText().trim();		
				 String memberPhonenumber = tfMemberPhone.getText().trim();	
				
				 if (memberName.isBlank() || memberId.isBlank() || memberEmail.isBlank() || memberPhonenumber.isBlank())
				 		{System.out.println ("Most Enter All Member's Information !! ");}
				 else{
				 //Sending member information to association setMemberList method.
				 association.setMemberlist(memberName, memberId, memberEmail, memberPhonenumber);
				 //Clearing text fields to be ready for next member.
				 tfMemberName.clear();
				 tfMemberId.clear();
				 tfMemberEmail.clear();
				 tfMemberPhone.clear();
				 
				 //System.out.println(counter+1);
				 counter++;
				 if (counter == this.numberOfMembers ) {
					 btAddMember.setDisable(true);
					 CreatePaidTable();
				 }	  
			 }
			  
			 } catch (Exception ex) {
				  // ex.printStackTrace();
				   System.out.println ("WRONG DATA WAS ENTERED !!");
				   }	
		  }
		  
		  

	   ///////////////////////////////////////////////////////////////////////////////////
	   // View Association Method
		 public void viewAssociation() {
			 System.out.println ("Association Information: ");
			 System.out.println ("Association Name: " + association.getAssociationName() + ", Number of Members: " + association.getNumberOfMembers() + ", Share: "+ association.getShareAmount() + ", Starting Month : " + association.getStartMonth());
			 System.out.println ();
			 
			 //Getting Administrator Information.
			 System.out.println ("Administerator Information: ");
			 System.out.println ("Name: " + association.getAdmin().getName() + ",  Id: " + association.getAdmin().getidNumber() + ", Phone_Nmber: "+ association.getAdmin().getPhoneNumber());
			 System.out.println ();
			 System.out.println("Member Name		" + "Member ID		" + "Email		" + "PhoneNumber");
		   		   
		   for (int i = 0; i < this.numberOfMembers; i++){
			   
			   //Get the first member from the list.
			   User member = association.getMember(i);
			   //get members properties and display them.
			   String memberName = member.getName();
			   String memberId = member.getidNumber();
			   String memberEmail = member.getEmailAddress();
			   String memberPhonenumber = member.getPhoneNumber();
			   System.out.println(memberName + "			" + memberId + "			" + memberEmail +  "		" + memberPhonenumber);
			  			  
		   }	
		   //Displaying payment table
		   displayPaymentTable ();
		   
	   }   
		 
		 //////////////////////////////////////////////////////////////////////////////////
		 //Creating payment table 
		 public void CreatePaidTable() {
			 
			 association.setMembersPaid(numberOfMembers);
			 lblCreatePT.setText("Payment Table Created");
		 }
		 
	    /////////////////////////////////////////////////////////////////////////////////
        //Method to display payment table.
		 public void displayPaymentTable () {
			 System.out.println();
			 System.out.println();
			 String[][] paymentTable = association.getMembersPaid();
			 for(int j= 0; j < numberOfMembers; j++) 
				 System.out.print("\t\tMonth " + (j+1)) ; 
			 	 System.out.print("\t\tRecieved?");
			 for (int i = 0; i<numberOfMembers; i++) {
				 System.out.println();
				 for(int j= 0; j < numberOfMembers+2; j++) {
					 System.out.print(paymentTable[i][j] + "   \t\t");
		 }
				 	 
	   }
			 System.out.println();
			 System.out.println();
			 System.out.println("N/P Not Paid. \nN/R Not Received.");
	 }
		
		 ////////////////////////////////////////////////////////////////////////////////
		 //Opening Payment Window
		 public void openPaidTableWindow() {
			 
			 //Adding controls to payment window pane
			 GridPane paymentWindow = new GridPane();
			 paymentWindow.setPadding(new Insets(5, 15, 5, 0));
			 paymentWindow.setHgap(5);
			 paymentWindow.setVgap(5);
			 paymentWindow.add(lblPRMember, 0, 1);
			 paymentWindow.add(tfPRMember, 1, 1);
			 paymentWindow.add(lblUpdateMonth, 0, 2);
			 paymentWindow.add(tfUpdateMonth, 1, 2);
			 paymentWindow.add(lblPaidRecieved, 0,3);	     
			 paymentWindow.add(tfPaidRecieved, 1, 3); 
			 paymentWindow.add(btUpdatePaymentTable,1,5);
			 paymentWindow.add(btViewPaymentTable, 1,6);
			 
			 //////////////////////////////////////////////
			 paymentWindow.setAlignment(Pos.CENTER);
			 paymentWindow.setStyle("-fx-padding: 16;");
			Scene paymentScene = new Scene(paymentWindow, 500, 300);
			
			//Button Functions
			btUpdatePaymentTable.setOnAction(e -> updatePaymentTable());
			btViewPaymentTable.setOnAction(e -> displayPaymentTable());
				 
				// Update Payment window (Stage)
				Stage updatePaymentWindow = new Stage();
				updatePaymentWindow.setTitle("Payment Window");
				updatePaymentWindow.setScene(paymentScene);			

				updatePaymentWindow.show();
			 
		 }
		 
		///////////////////////////////////////////////////////////////////////////////
		//Updating PaymentTable		 
		 public void updatePaymentTable() {
			try {
			 //getting payment table
			 String[][] paymentTable = association.getMembersPaid();
			 //Getting information from text fields of payment window.
			 String memberName = tfPRMember.getText().trim();	
			 int updateMonth =  Integer.parseInt(tfUpdateMonth.getText()); 
			 String paidRecieved = tfPaidRecieved.getText().trim();		
			 
			 //Searching for members row
			int memberRowIndex = 0;
			int  j=0;
			for (int i = 0; i < this.numberOfMembers ; i++ ) {
				if (paymentTable[i][j].equals(memberName)) {
					
					memberRowIndex = i;
					break;
					}
			}
			if (updateMonth == 0) 
					updateMonth = this.numberOfMembers+1;
			//Updating the right cell
			paymentTable[memberRowIndex][updateMonth]= paidRecieved;
			}catch (Exception ex) {
				  // ex.printStackTrace();
				   System.out.println ("WRONG DATA WAS ENTERED !!");
				   }	
			
		 }	 
	
	////////////////////////////////////////////////////////////////////////////////////
    //Main
	   public static void main(String[] args )  throws Exception  {
			
		   Application.launch(args);
	}	   
	   
}

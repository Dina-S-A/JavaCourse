
public class User {
	
	private String name;
	private String idNumber;
	private String emailAddress;
	private String phoneNumber;	
	private boolean admin;
	
	
	
	// Constructors
	public User () {}
	
	public User (String name,String idNumber,String emailAddress,String phoneNumber) {		
		this.name = name;
		this.idNumber = idNumber;
		this.emailAddress = emailAddress;
		this.phoneNumber = phoneNumber;
	}
	
	public User (String name,String idNumber,String emailAddress,String phoneNumber,boolean admin) {
		
		this.name = name;
		this.idNumber = idNumber;
		this.emailAddress = emailAddress;
		this.phoneNumber = phoneNumber;
		this.admin = admin;
			}
	
	//Setters Methods
	public void setName (String name) {
		
		this.name = name;
	}
	
	public void setIdNumber (String idNumber) {
		
		this.idNumber = idNumber;
	}

	public void setEmailAddress (String emailAddress) {
	
	this.emailAddress = emailAddress;
	}


	public void setPhoneNumber (String phoneNumber) {
		
		this.phoneNumber = phoneNumber;
	}
	
		
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	
	
	
	//Getters Methods
	
	public String getName() {
		return this.name;
	}
	
	public String getidNumber() {
		return this.idNumber;
	}
	
	public String getPhoneNumber() {
		return this.phoneNumber;
	}
	
	public String getEmailAddress() {
		return this.emailAddress;
	}
	
	
	
	//Authentication Method
	 public boolean validation (String userName, String Password) {
		 boolean validate = false;
		 return validate;
	 }
	 
	 public void getUserInfo () {
	 
	 System.out.println ("Member Name " + getName());
	 System.out.println ("Member ID " + getidNumber());
	 System.out.println ("Member Phone Number " + getPhoneNumber());
	 System.out.println ("Member email " + getEmailAddress());
	 
	 
	 }
	 ///////////////////////////////////////////////////////////////////////check
	 public void getFullUserInfo () {
		 System.out.println ("Member Name " + getName());
		 System.out.println ("Member ID " + getidNumber());
		 System.out.println ("Member Phone Number " + getPhoneNumber());
		 System.out.println ("Member email " + getEmailAddress());
		
		 
	 }
	 
}
	 


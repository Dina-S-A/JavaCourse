
public class Administrator extends User {

	
	//Variables
	
	private String associationName;
	
	//Constructor.
	
	public Administrator () {
		
	}
	
	public Administrator (String name,String idNumber,String emailAddress,String phoneNumber,boolean admin) {
		setName(name);
		setIdNumber(idNumber);
		setEmailAddress(emailAddress);
		setPhoneNumber(phoneNumber);
		setAdmin(admin);
		
		
	}
	
	
	//Methods
	
	public void setAssociationName (String name) {
		this.associationName = name;
		
	}
	
		
	
	public String getAssociationName () {
		
		return this.associationName;
	}

}

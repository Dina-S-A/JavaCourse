import java.util.ArrayList;

 
public class Association {
	
	private String associationName;
	private int numberOfMembers;	
	private float shareAmount;
	private String startMonth;	
	private Administrator admin;// = new Administrator();
	private ArrayList<User> membersList = new ArrayList<>(); //Members List
	private String[][] membersPaid; //Table to show who paid in which month
	//Recipient list
	
	//Constructors
	public Association () {}
	
	public Association(String name, int numberOfMembers, float shareAmount ,String staretMonth ) {
		this.associationName = name;
		this.numberOfMembers = numberOfMembers;
		this.shareAmount = shareAmount;
		this.startMonth = staretMonth;
	}
	
	//Methods	
	
	public void setAssociationName (String name) {
		this.associationName = name;
	}
	
	// public void recepientList (){}
	
	public void setShareAmount (float share) {
		this.shareAmount = share;
	}
	
	public void setStartMonth (String month) {
		this.startMonth = month;
	}
	
	// Constructing Administrator  object.
	public void setAdmin (String adminName, String adminId, String adminEmail, String adminPhone, boolean admin) {
		this.admin = new Administrator( adminName,  adminId,  adminEmail,  adminPhone, admin);
	}
	
	
	
	//Adding member details to the list.
	 public void setMemberlist (String memberName, String memberId, String memberEmail, String memberPhonenumber) {
		 		 
		 User member = new User(memberName, memberId, memberEmail, memberPhonenumber);
		 membersList.add(member);
	 }
	 
	 public void setMembersPaid (int numberOfMembers) {
		 
		 this.membersPaid = new String[numberOfMembers][numberOfMembers+2];
		 // Filling the first column with members' names.
				  int j = 0;
				  for(int i= 0; i < numberOfMembers; i++) {
				 membersPaid[i][j] = this.getMember(i).getName();				 
			 }
				  //Filling the table with N/P Not Paid in the beginning.
				   for (int i = 0; i<numberOfMembers; i++) {
						 for( j= 1; j < numberOfMembers+1; j++) {
							 membersPaid[i][j] = "N/P"; 
						 }
				 }
				   
				 //Mark the last column as Not Received N/R
				   j= numberOfMembers+1;
				   for (int i = 0; i<numberOfMembers; i++) {
					   membersPaid[i][j] = "N/R"; 
				   }   
	 }
	
	
	//Getter Methods
	
	//public array getRecepientList(){}
	
	public String getAssociationName () {
		 return this.associationName;
		
	}
	
	public int getNumberOfMembers () {
		
		return this.numberOfMembers;
	}
	
	
	public float getShareAmount() {
		return this.shareAmount;
	}
	
	
	public String getStartMonth() {
		return this.startMonth;
	}
	
	public Administrator getAdmin() {
		
		return this.admin;
		
	}
	 public ArrayList<User> getMemebrsList () {
		 return membersList; 
	 }	
	 
	 public User getMember (int index) {
		 return membersList.get(index);
		 
	 }
	 
	 public String[][] getMembersPaid () {
		 return membersPaid ;
	 }
	 
}
